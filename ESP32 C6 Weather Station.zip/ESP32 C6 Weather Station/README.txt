Building a Mini Macintosh Weather Station with ESP32! by The_Wrench_DIY on Thingiverse: https://www.thingiverse.com/thing:6887697

Summary:
Yo! What's up, guys? In today’s video, I’m taking you through the process of creating a super cute Mini Macintosh that’s actually a weather station! Watch Tutorial Here: https://youtu.be/2_iKr0vAOlE
